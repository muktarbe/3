public class Circle {
    private static double PI=3.14;
    public static double area(double radius){
        double chek= PI * (radius * radius);
        return chek;
    }
    public static double circumference(double radius){
        double chek= PI * 2 * radius;
        return chek;
    }
}
